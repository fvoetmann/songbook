# Script Templates

Full annotated templates for each pipeline script. Adapt field names and filter logic to the topic.

---

## `{topic}_review.py` — Fetch from OpenAlex

```python
import requests
import pandas as pd
import time
from typing import Optional

MAILTO = "your@email.com"  # replace with user's email
BASE_URL = "https://api.openalex.org/works"

def reconstruct_abstract(inverted_index: Optional[dict]) -> str:
    if not inverted_index:
        return ""
    positions = []
    for word, pos_list in inverted_index.items():
        for pos in pos_list:
            positions.append((pos, word))
    positions.sort()
    return " ".join(word for _, word in positions)

def fetch_works(search_term: str, mailto: str) -> list:
    results = []
    cursor = "*"
    params = {
        "filter": f"title.search:{search_term}",
        "select": "id,doi,title,publication_year,type,language,cited_by_count,"
                  "concepts,topics,abstract_inverted_index,best_oa_location,locations",
        "per-page": 200,
        "mailto": mailto,
        "cursor": cursor,
    }
    while True:
        response = requests.get(BASE_URL, params=params)
        response.raise_for_status()
        data = response.json()
        batch = data.get("results", [])
        if not batch:
            break
        results.extend(batch)
        cursor = data.get("meta", {}).get("next_cursor")
        if not cursor:
            break
        params["cursor"] = cursor
        time.sleep(0.12)
    return results

def extract_pdf_url(work: dict) -> str:
    best = work.get("best_oa_location") or {}
    if best.get("pdf_url"):
        return best["pdf_url"]
    for loc in work.get("locations", []):
        if loc.get("pdf_url"):
            return loc["pdf_url"]
    return ""

def works_to_rows(works: list) -> list:
    rows = []
    for w in works:
        concepts = "; ".join(c.get("display_name", "") for c in w.get("concepts", []))
        topics = "; ".join(t.get("display_name", "") for t in w.get("topics", []))
        rows.append({
            "id": w.get("id", ""),
            "doi": w.get("doi", ""),
            "title": w.get("title", ""),
            "year": w.get("publication_year"),
            "type": w.get("type", ""),
            "language": w.get("language", ""),
            "cited_by_count": w.get("cited_by_count", 0),
            "concepts": concepts,
            "topics": topics,
            "abstract": reconstruct_abstract(w.get("abstract_inverted_index")),
            "best_oa_pdf_url": extract_pdf_url(w),
        })
    return rows

# --- Main ---
search_terms = [
    "TERM ONE",   # adapt to topic
    "TERM TWO",
    "TERM THREE",
]

all_works = {}
for term in search_terms:
    print(f"Fetching: {term}")
    works = fetch_works(term, MAILTO)
    print(f"  Got {len(works)} results")
    for w in works:
        all_works[w["id"]] = w  # deduplicate by OpenAlex ID

rows = works_to_rows(list(all_works.values()))
df = pd.DataFrame(rows)
df.to_csv("{topic}_literature.csv", index=False)
print(f"Saved {len(df)} papers to {topic}_literature.csv")
```

---

## `classify_relevance.py` — Pass 1

```python
import pandas as pd

df = pd.read_csv("{topic}_literature.csv")

CORE_TERMS = ["term one", "term two"]        # must appear in title/abstract
CONTEXT_SIGNALS = ["higher education", "university", "college", "faculty"]
EXCLUDE_TECHNICAL = ["machine learning", "neural network", "training algorithm"]
EXCLUDE_OTHER = ["k-12", "elementary school", "special education"]

def classify(row):
    title = str(row.get("title", "")).lower()
    abstract = str(row.get("abstract", "")).lower()
    text = title + " " + abstract

    has_core = any(t in text for t in CORE_TERMS)
    has_context = any(s in text for s in CONTEXT_SIGNALS)
    is_technical = any(t in text for t in EXCLUDE_TECHNICAL)
    is_other = any(t in text for t in EXCLUDE_OTHER)

    if not has_core:
        return "IRRELEVANT", "No core term found"
    if is_technical:
        return "IRRELEVANT_TECHNICAL", "Technical/ML use of term"
    if is_other:
        return "POSSIBLE_OTHER", "Core term in non-target context"
    if has_context:
        return "RELEVANT", "Core term + context signal"
    return "POSSIBLE_HE", "Core term present, context uncertain"

df[["relevance", "relevance_reason"]] = df.apply(
    lambda r: pd.Series(classify(r)), axis=1
)
df.to_csv("{topic}_classified.csv", index=False)

# Report
for cat, grp in df.groupby("relevance"):
    print(f"{cat}: {len(grp)}")
```

---

## `classify_core.py` — Pass 2

```python
import pandas as pd

df = pd.read_csv("{topic}_classified.csv")
subset = df[df["relevance"].isin(["RELEVANT", "POSSIBLE_HE", "POSSIBLE_OTHER"])].copy()

CORE_SIGNALS = [
    "we examine", "we investigate", "we explore", "this study", "this paper",
    "research question", "findings", "implications for",
    # add topic-specific signals
]
PERIPHERAL_SIGNALS = [
    "as a method", "using a", "delivered via", "course design",
    # signals that topic is just delivery vehicle, not focus
]

def classify_core(row):
    abstract = str(row.get("abstract", "")).lower()
    title = str(row.get("title", "")).lower()
    text = abstract + " " + title

    core_hits = sum(1 for s in CORE_SIGNALS if s in text)
    peripheral_hits = sum(1 for s in PERIPHERAL_SIGNALS if s in text)

    if core_hits >= 2 or (core_hits >= 1 and peripheral_hits == 0):
        return "CORE", f"{core_hits} core signals"
    return "PERIPHERAL", f"Only {core_hits} core signal(s), {peripheral_hits} peripheral"

subset[["relevance2", "relevance2_reason"]] = subset.apply(
    lambda r: pd.Series(classify_core(r)), axis=1
)

df = df.merge(
    subset[["id", "relevance2", "relevance2_reason"]],
    on="id", how="left"
)
df.to_csv("{topic}_classified2.csv", index=False)

print(df["relevance2"].value_counts())
```

---

## `produce_final.py` — Pass 3

```python
import pandas as pd

df = pd.read_csv("{topic}_classified2.csv")

# Hard filters
filtered = df[
    (df["relevance2"] == "CORE") &
    (df["language"] == "en") &
    (df["type"].isin(["article", "review", "book-chapter"])) &
    (df["year"] >= 2015)  # adjust cutoff
].copy()

# Citation tiers
def assign_tier(n):
    if n >= 50:   return "A  50+ citations"
    if n >= 20:   return "B  20-49 citations"
    if n >= 10:   return "C  10-19 citations"
    if n >= 5:    return "D  5-9 citations"
    if n >= 1:    return "E  1-4 citations"
    return "F  0 citations"

filtered["citation_tier"] = filtered["cited_by_count"].apply(assign_tier)
filtered = filtered.sort_values(
    ["citation_tier", "year"], ascending=[True, False]
)

filtered.to_csv("{topic}_final_by_citations.csv", index=False)

# Report tier counts
print(filtered["citation_tier"].value_counts().sort_index())
print(f"\nTotal: {len(filtered)} papers")
```

---

## `make_bibtex_and_pdfs.py` — BibTeX + PDF download

```python
import requests
import pandas as pd
import time
import os
import re
from typing import Optional

MAILTO = "your@email.com"
PDF_DIR = "pdfs A-C"
os.makedirs(PDF_DIR, exist_ok=True)

df = pd.read_csv("{topic}_final_by_citations.csv")
# Filter to working tiers, e.g.:
working = df[df["citation_tier"].isin(["A  50+ citations", "B  20-49 citations", "C  10-19 citations"])]

def make_cite_key(row: dict, used: set) -> str:
    author = row.get("author_last", "Unknown")
    year = str(row.get("year", "0000"))
    base = re.sub(r"[^A-Za-z]", "", author) + year
    key = base
    suffix_idx = 0
    while key in used:
        key = base + "abc"[suffix_idx]
        suffix_idx += 1
    used.add(key)
    return key

def fetch_extra_metadata(openalex_id: str, mailto: str) -> dict:
    url = openalex_id.replace("https://openalex.org/", "https://api.openalex.org/works/")
    r = requests.get(url, params={"mailto": mailto})
    if r.status_code != 200:
        return {}
    data = r.json()
    bib = data.get("biblio", {})
    authors = data.get("authorships", [])
    author_str = " and ".join(
        a.get("author", {}).get("display_name", "") for a in authors
    )
    primary_loc = data.get("primary_location") or {}
    source = primary_loc.get("source") or {}
    return {
        "author_str": author_str,
        "journal": source.get("display_name", ""),
        "volume": bib.get("volume", ""),
        "issue": bib.get("issue", ""),
        "first_page": bib.get("first_page", ""),
        "last_page": bib.get("last_page", ""),
        "entry_type": "article" if data.get("type") == "article" else "misc",
    }

def download_pdf(url: str, path: str) -> bool:
    try:
        r = requests.get(url, timeout=20, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200 and len(r.content) > 1000:
            with open(path, "wb") as f:
                f.write(r.content)
            return True
    except Exception:
        pass
    return False

used_keys = set()
entries = []
download_log = []

for _, row in working.iterrows():
    meta = fetch_extra_metadata(row["id"], MAILTO)
    time.sleep(0.12)

    cite_key = make_cite_key({"author_last": meta.get("author_str", "").split()[0], "year": row["year"]}, used_keys)

    doi = str(row.get("doi", "")).replace("https://doi.org/", "")
    pages = ""
    if meta.get("first_page") and meta.get("last_page"):
        pages = f"{meta['first_page']}--{meta['last_page']}"

    entry_type = meta.get("entry_type", "article")
    journal_field = "journal" if entry_type == "article" else "booktitle"

    bib = f"""@{entry_type}{{{cite_key},
  author   = {{{meta.get('author_str', '')}}},
  title    = {{{row.get('title', '')}}},
  {journal_field} = {{{meta.get('journal', '')}}},
  year     = {{{row.get('year', '')}}},
  volume   = {{{meta.get('volume', '')}}},
  number   = {{{meta.get('issue', '')}}},
  pages    = {{{pages}}},
  doi      = {{{doi}}},
  url      = {{{row.get('id', '')}}},
  abstract = {{{row.get('abstract', '')}}},
}}"""
    entries.append(bib)

    # Attempt PDF download
    pdf_url = row.get("best_oa_pdf_url", "")
    if pdf_url:
        ext = ".html" if "html" in pdf_url.lower() else ".pdf"
        path = os.path.join(PDF_DIR, cite_key + ext)
        success = download_pdf(pdf_url, path)
        download_log.append(f"{'OK' if success else 'FAIL'}: {cite_key} — {pdf_url}")
    else:
        download_log.append(f"NO_URL: {cite_key}")

with open("{topic}_AC.bib", "w", encoding="utf-8") as f:
    f.write("\n\n".join(entries))

with open("download_log.txt", "w") as f:
    f.write("\n".join(download_log))

print(f"BibTeX: {len(entries)} entries")
print(f"Download log: {len(download_log)} entries")
```
