---
name: literature-review
description: >
  Use this skill whenever the user wants to conduct an academic literature review, search for research papers, build a bibliography, or synthesise research on a topic. Triggers include: "lav et litteraturreview", "find artikler om", "søg på OpenAlex", "byg en BibTeX-fil", "skriv en tematisk oversigt", "download relevante PDFs", or any request to survey, map, or summarise a research field. Also use when the user asks to screen, classify, or filter a set of papers, or wants to download open-access full texts. Even if the user only asks for one part of the pipeline (e.g. "lav bare en BibTeX-fil"), use this skill to ensure consistent conventions.
---

# Literature Review Skill

A reproducible pipeline for academic literature reviews using the OpenAlex API. Produces a BibTeX file, thematic markdown overview, and downloaded open-access PDFs.

## Pipeline overview

```
Topic → Fetch (OpenAlex) → Pass 1 screen → Pass 2 screen → Pass 3 filter
      → Citation tiers → BibTeX → Thematic overview → PDF download
```

Work in a dedicated project folder, e.g. `my-topic/`. All scripts go there. See `references/scripts.md` for full script templates.

---

## Step 1 — Fetch from OpenAlex

**Script:** `{topic}_review.py`

### API conventions (always follow these)
- **Title-only search**: `filter=title.search:{term}` — avoids millions of false positives from full-text `search=`
- **Polite pool**: always pass `mailto=` parameter for faster, prioritised responses — ask the user for their email address if not provided
- **Cursor pagination**: `cursor=*` to start, follow `meta.next_cursor` until `None`; max 200 results per page
- **Selective fields**: use `select=` to request only needed fields; reduces payload
- **Abstracts**: returned as inverted index (`abstract_inverted_index`); reconstruct with a `reconstruct_abstract()` helper
- **Rate limiting**: `time.sleep(0.12)` between requests

### Multiple search terms
Run 2–4 complementary title searches to capture synonyms and related terms (e.g. "co-teaching" + "team teaching" + "collaborative teaching"). Deduplicate by OpenAlex ID.

### Output
`{topic}_literature.csv` — one row per paper, columns including:
`id, doi, title, year, type, language, cited_by_count, concepts, topics, abstract, best_oa_pdf_url`

Typical raw fetch: 3,000–15,000 papers across search terms.

---

## Step 2 — Pass 1: Relevance screening

**Script:** `classify_relevance.py`

Rule-based filter on title, abstract, concepts, and topics. Adds `relevance` and `relevance_reason` columns to the CSV.

**Standard categories:**
- `RELEVANT` — core term present + confirmed target context (e.g. HE signal)
- `POSSIBLE_HE` — core term present, context uncertain
- `POSSIBLE_OTHER` — term present but wrong context (K-12, clinical, etc.)
- `IRRELEVANT_TECHNICAL` — term used in unrelated technical sense (e.g. "co-teaching" in ML)
- `IRRELEVANT` — off-topic

Adapt category names to the topic. Document the rules explicitly in the script as comments.

**Output:** `{topic}_classified.csv`

---

## Step 3 — Pass 2: Focus screening

**Script:** `classify_core.py`

Applied to `RELEVANT` + `POSSIBLE_*` rows only. Determines whether the topic is the *object of study* (not merely the delivery method or context). Adds `relevance2` and `relevance2_reason` columns.

**Standard categories:**
- `CORE` — topic is the research focus
- `PERIPHERAL` — topic appears incidentally

**Output:** `{topic}_classified2.csv`

---

## Step 4 — Pass 3: Final filter

**Script:** `produce_final.py`

Hard filters applied to produce the working bibliography:
- Language = English only
- Document type ∈ {article, review, book-chapter}
- Year ≥ [agree with user — default: 10 years back]
- Abstract-level exclusions based on patterns found in Pass 1–2

Adds `citation_tier` column:

| Tier | Range | Notes |
|---|---|---|
| `A  50+ citations` | ≥50 | Often paywalled |
| `B  20-49 citations` | 20–49 | |
| `C  10-19 citations` | 10–19 | |
| `D  5-9 citations` | 5–9 | |
| `E  1-4 citations` | 1–4 | |
| `F  0 citations` | 0 | Many recent papers |

Sort by tier then year descending.

**Working bibliography target: 30–100 papers** (typically Tier A–C, or A–D for newer fields). Discuss cut-off with user.

**Output files:**
- `{topic}_final.csv` — filtered papers
- `{topic}_final_by_citations.csv` — same + `citation_tier`, sorted

---

## Step 5 — BibTeX generation

**Script:** `make_bibtex_and_pdfs.py`

For each paper in the working bibliography:
1. Fetch full metadata from OpenAlex API (volume, issue, pages, etc.)
2. Build BibTeX entry

### BibTeX conventions
- **Cite key format**: `AuthorYear` (e.g. `Morelock2017`), with `a/b/c` suffix for same-author/same-year collisions
- **Entry types**: `@article`, `@incollection`, `@misc` (for preprints/unclear)
- **Fields**: `author`, `title`, `journal`/`booktitle`, `year`, `volume`, `number`, `pages`, `doi`, `url` (OpenAlex link), `abstract`, `keywords`
- Sort entries by citation count descending

**Output:** `{topic}_AC.bib` (or whichever tiers are included)

Also attempt PDF download for each paper (see Step 6 below).

---

## Step 6 — PDF download

Done inside `make_bibtex_and_pdfs.py` or a separate `download_pdfs.py`.

- Check `best_oa_location.pdf_url` first, then iterate `locations[n].pdf_url`
- Save as `{cite_key}.pdf` (or `.html` if only HTML full text available)
- Store in `pdfs {tiers}/` subfolder (e.g. `pdfs A-C/`)
- `time.sleep(0.12)` between requests
- Log any download failures to `download_log.txt`
- Note paywalled papers for manual download

---

## Step 7 — Thematic overview

**Output:** `{topic}_oversigt.md`

Write a thematic synthesis (~2,000–3,500 words) based on the abstracts (and any downloaded full texts). Structure:

1. Conceptual landscape — definitions, models, scope
2. [Topic-specific themes — 4–6 sections based on what emerges from the literature]
3. Methodological patterns (if relevant)
4. Gaps and future directions

**Citation format:** `@CiteKey` — compatible with Pandoc/Quarto using `bibliography: {topic}_AC.bib`.

**Language:** Match the user's language (dansk or English) unless they specify otherwise.

---

## Step 8 — Printable bibliography (optional)

**Script:** `make_bibliography_pdf.py`

Generates a PDF bibliography from the BibTeX file with clickable DOI and OpenAlex links. Useful for paywalled papers that require manual download.

---

## Python environment notes

- Default to Python 3.9 compatibility: avoid `X | Y` union syntax and `list[dict]` generics — use bare `list`, `dict`, or `Optional` from `typing`
- Dependencies: `requests`, `pandas` (install with pip)
- For PDF generation: `fpdf2` or `reportlab`

---

## Project folder structure

```
my-topic/
├── CLAUDE.md                          ← project memory (generate this too)
├── {topic}_review.py                  ← fetch script
├── classify_relevance.py              ← Pass 1
├── classify_core.py                   ← Pass 2
├── produce_final.py                   ← Pass 3
├── make_bibtex_and_pdfs.py            ← BibTeX + PDF download
├── make_bibliography_pdf.py           ← printable bibliography
├── {topic}_literature.csv             ← raw fetch
├── {topic}_classified.csv             ← after Pass 1
├── {topic}_classified2.csv            ← after Pass 2
├── {topic}_final_by_citations.csv     ← working bibliography
├── {topic}_AC.bib                     ← BibTeX
├── {topic}_oversigt.md                ← thematic overview
├── download_log.txt                   ← PDF download log
└── pdfs A-C/                          ← downloaded full texts
```

---

## CLAUDE.md generation

At the end of the pipeline (or after major milestones), generate or update a `CLAUDE.md` in the project folder documenting:
- What has been done
- Key output files (table with descriptions)
- Screening pipeline decisions (rules used, categories, counts)
- Citation tier counts
- BibTeX conventions used
- Known data quality issues
- How to re-run each script

This makes the project resumable in a new session.

---

## Starting a new review — checklist

1. Agree on topic and search terms with user
2. Ask for email address (for OpenAlex polite pool)
3. Ask for year cutoff (default: 10 years)
4. Ask for target tier cut-off (default: Tier A–C, ≥10 citations)
5. Ask for output language (dansk/English)
6. Create project folder and write fetch script
7. Run pipeline step by step, reporting counts at each stage
8. Discuss tier cut-off after seeing the citation distribution
9. Generate BibTeX, overview, and attempt PDF downloads
10. Write CLAUDE.md to capture project state

See `references/scripts.md` for full annotated script templates.
